import cv2
from os import path
import numpy as np
import random


def newPage():
    global lno,page,line,pop
    page = appendLine(line)
    line = cv2.imread(folder+"/32.png")
    for i in range(width-line.shape[1]):line = cv2.hconcat([line,cv2.imread(folder+"/wh.png")])
    for i in range(35-lno-1):
        page = appendLine(line)
    pop += 1
    lno = 0
    print("Completed Writing Page "+str(pop))
    cv2.imwrite(outputFolder+"/"+str(pop)+".png",page)
    page = cv2.imread(folder+"/wh.png")
    for i in range(width-1):page = cv2.hconcat([page,cv2.imread(folder+"/wh.png")])


def reset():
    global line,words
    line = cv2.imread(folder+"/32.png")
    words = cv2.imread(folder+"/wh.png")

pop = 0
def appendLine(line):
    global page,pop,lno
    lno += 1
    if lno > 35:
        lno = 0
        pop += 1
        print("Completed Writing Page "+str(pop))
        cv2.imwrite(outputFolder+"/"+str(pop)+".png",page)
        page = cv2.imread(folder+"/wh.png")
        for i in range(width-1):page = cv2.hconcat([page,cv2.imread(folder+"/wh.png")])
    for i in range(width-line.shape[1]):
        line = cv2.hconcat([line,cv2.imread(folder+"/wh.png")])
    # print(page.shape,line.shape)
    page = cv2.vconcat([page,line])
    line = cv2.imread(folder+"/32.png")
    return page

def appendWord(line,words):
    global page
    if line.shape[1]+words.shape[1] > width:
        for i in range(width-line.shape[1]):
            line = cv2.hconcat([line,cv2.imread(folder+"/wh.png")])
        page = appendLine(line)
        line = cv2.imread(folder+"/32.png")
    line = cv2.hconcat([line,words])
    return line

def appendLetter(words,let):
    global folder;
    # folder = str(random.choice((1,2,3)))
    try:
        temp = cv2.imread(folder+"/"+str(ord(let))+".png")
        words = cv2.hconcat([words,temp])
    except:
        pass
    return words


# Width of the paper (in px)
width = 1000
# folder that contains all the characters
folder = "1"
outputFolder = "OP"
string = input("Enter a String:")
page = cv2.imread(folder+"/wh.png")
for i in range(width-1):page = cv2.hconcat([page,cv2.imread(folder+"/wh.png")])
line = cv2.imread(folder+"/32.png")
words = cv2.imread(folder+"/32.png")
lno = 0

sp = cv2.imread(folder+"/32.png")
px = cv2.imread(folder+"/wh.png")
chars = 0 
string = string+"|nl|"
while(chars < len(string)):
    if string[chars] == " ":
        line = appendWord(line,words)
        words = cv2.imread(folder+"/32.png")
    elif string[chars] == "|":
        if string[chars+1:chars+3] == "nl":
            line = appendWord(line,words)
            words = cv2.imread(folder+"/32.png")
            appendLine(line)
            line = cv2.imread(folder+"/32.png")
            chars += 2
        elif string[chars+1:chars+3] =="vs":
            temp = int(string[chars+1:-1].split("|")[0].split(":")[1])
            line = appendWord(line,words)
            words = cv2.imread(folder+"/32.png")
            for i in range(temp):
                appendLine(line)
                line = cv2.imread(folder+"/32.png")
            chars += 5
        elif string[chars+1:chars+6] == "color":
            temp = string[chars+1:-1].split("|")[0].split(":")[1]
            if temp[0] == "[":
                temp = temp[1:-1].split(",")
                clr = [temp[0],temp[1],temp[2]]
                text = string[chars+1:-1].split("|")[1]
                for j in text:
                    if j == " ":
                        words[np.where((words<=[200, 200, 200]).all(axis=2))] = clr
                        line = cv2.hconcat([line,words])
                        words = cv2.imread(folder+"/wh.png")
                    if path.exists(folder+"/"+str(ord(j))+".png"):
                        temp = cv2.imread(folder+"/"+str(ord(j))+".png")
                    else:
                        temp = cv2.imread(folder+"/wh.png")
                    if line.shape[1]+words.shape[1] > width:
                        for i in range(width-line.shape[1]):
                            line = cv2.hconcat([line,cv2.imread(folder+"/wh.png")])
                        page = cv2.vconcat([page,line])
                        line = cv2.imread(folder+"/wh.png")
                    words = cv2.hconcat([words,temp])
                words[np.where((words<=[200, 200, 200]).all(axis=2))] = clr
            n = string[chars+1:-1].split("|")
            n = len(n[0])+len(n[1])
            chars+=n+1
        elif string[chars+1:chars+9] == "fontsize":
            temp =string[chars+1:-1].split("|")[1]
            scale = float(string[chars+1:-1].split("|")[0].split(':')[1])
            # print(temp,scale)
            appendLine(line)
            line = line = cv2.imread(folder+"/wh.png")
            for i in temp:
                words = appendLetter(words,i)
            # print(line.shape,words.shape)
            words = cv2.resize(words,(int(words.shape[1]*scale),int(words.shape[0]*scale)) , interpolation= cv2.INTER_LINEAR)
            line = cv2.resize(line,(int(line.shape[1]*scale),int(line.shape[0]*scale)) , interpolation= cv2.INTER_LINEAR)
            # print(line.shape,words.shape)
            line = appendWord(line,words)
            t2 =cv2.resize(px,(1,int(px.shape[0]*scale)) , interpolation= cv2.INTER_LINEAR)
            for k in range(width-line.shape[1]):
                # print(line.shape,t2.shape)
                line = cv2.hconcat([line,t2])
            for n in range(width-line.shape[1]):
                line = cv2.hconcat([line,cv2.resize(px,(int(px.shape[1]*scale),int(px.shape[0]*scale)) , interpolation= cv2.INTER_LINEAR)])
            page = cv2.vconcat([page,line])
            line = cv2.imread(folder+"/32.png")
            line = appendWord(line,line)
            words = cv2.imread(folder+"/wh.png")
            chars += len(string[chars+1:-1].split("|")[1])+len(string[chars+1:-1].split("|")[0])+1
        elif string[chars+1:chars+3] == "np":
            line = appendWord(line,words)
            newPage()
            chars += 2
        elif string[chars+1:chars+5] == "head":
            clr = string[6:].split('|')[0].split()[0][1:-1].split(',')
            clr =[clr[0],clr[1],clr[2]]
            scale = float(string[6:].split('|')[0].split()[1])
            temp = string[6:].split('|')[1]
            # print(temp,clr,scale)
            appendLine(line)
            line = line = cv2.imread(folder+"/wh.png")
            for i in temp:
                words = appendLetter(words,i)
            # print(line.shape,words.shape)
            words = cv2.resize(words,(int(words.shape[1]*scale),int(words.shape[0]*scale)) , interpolation= cv2.INTER_LINEAR)
            line = cv2.resize(line,(int(line.shape[1]*scale),int(line.shape[0]*scale)) , interpolation= cv2.INTER_LINEAR)
            # print(line.shape,words.shape)
            line = appendWord(line,words)
            t2 =cv2.resize(px,(1,int(px.shape[0]*scale)) , interpolation= cv2.INTER_LINEAR)
            for k in range(width-line.shape[1]):
                # print(line.shape,t2.shape)
                line = cv2.hconcat([line,t2])
            for n in range(width-line.shape[1]):
                line = cv2.hconcat([line,cv2.resize(px,(int(px.shape[1]*scale),int(px.shape[0]*scale)) , interpolation= cv2.INTER_LINEAR)])
            line[np.where((line<=[200, 200, 200]).all(axis=2))] = clr
            page = cv2.vconcat([page,line])
            line = cv2.imread(folder+"/32.png")
            line = appendWord(line,line)
            words = cv2.imread(folder+"/wh.png")
            chars += len(string[chars+1:].split('|')[0]) + len(string[chars+1:].split('|')[1]) + 2
            

    else:
        words = appendLetter(words,string[chars])
    chars += 1
appendWord(line,words)
appendLine(line)
line = cv2.imread(folder+"/wh.png")
for i in range(width-1):line = cv2.hconcat([line,cv2.imread(folder+"/wh.png")])
for i in range(35-lno):
    appendLine(line)
pop+=1
print("Completed Writing Page "+str(pop))
cv2.imwrite(outputFolder+"/"+str(pop)+".png",page)
print("Comleted Writing Document")