import pygame
import cv2

imageToBeCropped = "Alphabet.jpg"
destinationFolder = "3"
height = 68
c = 32
precision = 0.1


im = cv2.imread(imageToBeCropped)
image = pygame.image.load(imageToBeCropped)
win = pygame.display.set_mode((400,400))
pygame.display.set_caption("Cropper")
x = 0
y = 0
ix = 0
iy =0 
width = 40
loop = True
while loop:
    win.fill((255,255,255,128))
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            loop = False
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_RETURN:
                img = im[int(y)-int(iy):int(y)-int(iy)+int(height),int(x)-int(ix):int(x)-int(ix)+int(width)]
                cv2.imwrite(destinationFolder+"/"+str(c)+".png",img)
                c += 1
            if e.key == pygame.K_KP_PLUS:
                precision += 0.1
            if e.key == pygame.K_KP_MINUS:
                precision -= 0.1
            if e.key == pygame.K_b:
                c -= 1

    
    keys=pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        x -= precision
    if keys[pygame.K_RIGHT]:
        x += precision
    if keys[pygame.K_DOWN]:
        y += precision
    if keys[pygame.K_UP]:
        y -= precision
    if keys[pygame.K_w]:
        iy -= precision
    if keys[pygame.K_s]:
        iy += precision
    if keys[pygame.K_a]:
        ix -= precision
    if keys[pygame.K_d]:
        ix += precision
    if keys[pygame.K_COMMA]:
        width -= precision
    if keys[pygame.K_PERIOD]:
        width += precision
    if keys[pygame.K_o]:
        height += precision
    if keys[pygame.K_l]:
        height -= precision
    if precision <0 :
        precision = 0
    win.blit(image,(int(ix),int(iy)))
    pygame.draw.rect(win, pygame.Color(0,0,0), pygame.Rect(int(x),int(y),int(width),int(height)),3)
    pygame.draw.line(win, pygame.Color(0,0,0),(int(x),int(y + (0.6)*height)),(int(x+width),int(y + (0.6)*height)),2)
    pygame.display.update()